/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package binarytreepractice;

class Node
{
    String desc;
    Node left;
    Node right;
    
    public Node(String desc) 
    {
       this.desc = desc;
       this.left = left;
       this.right = right;
    }
    
    public String desc()
    {
        return desc;
    }
    
    public Node left()
    {
        return left;
    }
    
    public Node right()
    {
        return right;
    }
}